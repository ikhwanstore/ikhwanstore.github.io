<?php
$host = "localhost";
$tableprefix = "whatsstore_"; //Anda dapat mengubah awalan tabel ini, jangan gunakan spasi putih, gunakan garis bawah sebagai gantinya misalnya whatsstore22_is_my_table_prefix_
$databasename = ""; //nama database
$dbuser = ""; //nama user database
$dbpassword = ""; //pw user database